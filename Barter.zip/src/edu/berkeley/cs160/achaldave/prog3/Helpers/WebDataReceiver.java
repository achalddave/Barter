package edu.berkeley.cs160.achaldave.prog3.Helpers;

import java.io.InputStream;

public interface WebDataReceiver {
	public void receive(InputStream in);
}