/** Automatically generated file. DO NOT MODIFY */
package edu.berkeley.cs160.achaldave.prog3;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}