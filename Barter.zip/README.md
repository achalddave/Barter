Barter
======

160 Individual Programming Assignment 3

# Why is this on Github

Because my hard drive is in Berkeley, I'm in SD, and I have a vague feelin that my laptop will screw me over and not let me turn this in tonight.

Also this is due soon so please excuse the hardcoded strings and camelcase + underscore mixing for xml IDs :)
